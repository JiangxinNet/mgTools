
cp autoload/*.vim /usr/share/vim/vim${version}/autoload/ -rvf
cp plugin/*.vim /usr/share/vim/vim${version}/plugin/ -rvf

cp ./vimrc.local /etc/vim/ -rvf or cat ./vimrc.local >> /etc/vim/vimrc.local
